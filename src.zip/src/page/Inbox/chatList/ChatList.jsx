import "./chatList.css";
import { Card, Badge } from "react-bootstrap";
import { fetchCustomer } from "./src/data/customer";
import { useEffect, useState } from "react";

const ChatList = () => {
  const [customer, setCustomer] = useState([]);
  const [cus, setCus] = useState([]);

  const Status = (id) => {
    setCustomer((prev) =>
      prev.map((c) => (c.id === id ? { ...c, inprocess: !c.inprocess } : c))
    );
  };

  useEffect(() => {
    setCustomer(fetchCustomer());
  });

  const visibleCustomer = cus.slice;

  return (
    <div className="overflow-y-auto flex-grow-1 pt-3">
      <Card className="custom-card-chat">
        {visibleCustomer.map((cus) => {
          return (
            <Card.Body className="d-flex align-items-center gap-3">
              {/* Profile Picture */}
              <img
                src={cus.img}
                className="rounded-circle"
                style={{ width: "60px", height: "60px", objectFit: "cover" }}
              />
              {/* Texts */}
              <div
                className="d-flex flex-column gap-1"
                style={{ height: "50px" }}
              >
                <div className="d-flex gap-3">
                  {/* Username */}
                  <span style={{ fontSize: "18px" }}>Harumasa</span>
                  {/* Status */}
                  <Badge className="bg-warning custom-badge">
                    กำลังดำเนินการ
                  </Badge>
                </div>
                {/* Massage */}
                <p className="custom-text">Lorem ipsum dolor sit amet.</p>
              </div>
            </Card.Body>
          );
        })}
      </Card>

      <Card className="custom-card-chat">
        <Card.Body className="d-flex align-items-center gap-3">
          {/* Profile Picture */}
          <img
            src="./src/assets/Image/Customers/Harumasa.png"
            className="rounded-circle"
            style={{ width: "60px", height: "60px", objectFit: "cover" }}
          />
          {/* Texts */}
          <div className="d-flex flex-column gap-1" style={{ height: "50px" }}>
            <div className="d-flex gap-3">
              {/* Username */}
              <span style={{ fontSize: "18px" }}>Harumasa</span>
              {/* Status */}
              <Badge className="bg-warning custom-badge">กำลังดำเนินการ</Badge>
            </div>
            {/* Massage */}
            <p className="custom-text">Lorem ipsum dolor sit amet.</p>
          </div>
        </Card.Body>
      </Card>

      <Card className="custom-card-chat">
        <Card.Body className="d-flex align-items-center gap-3">
          {/* Profile Picture */}
          <img
            src="./src/assets/Image/Customers/Harumasa.png"
            className="rounded-circle"
            style={{ width: "60px", height: "60px", objectFit: "cover" }}
          />
          {/* Texts */}
          <div className="d-flex flex-column gap-1" style={{ height: "50px" }}>
            <div className="d-flex gap-3">
              {/* Username */}
              <span style={{ fontSize: "18px" }}>Harumasa</span>
              {/* Status */}
              <Badge className="bg-warning custom-badge">กำลังดำเนินการ</Badge>
            </div>
            {/* Massage */}
            <p className="custom-text">Lorem ipsum dolor sit amet.</p>
          </div>
        </Card.Body>
      </Card>

      <Card className="custom-card-chat">
        <Card.Body className="d-flex align-items-center gap-3">
          {/* Profile Picture */}
          <img
            src="./src/assets/Image/Customers/Harumasa.png"
            className="rounded-circle"
            style={{ width: "60px", height: "60px", objectFit: "cover" }}
          />
          {/* Texts */}
          <div className="d-flex flex-column gap-1" style={{ height: "50px" }}>
            <div className="d-flex gap-3">
              {/* Username */}
              <span style={{ fontSize: "18px" }}>Harumasa</span>
              {/* Status */}
              <Badge className="bg-warning custom-badge">กำลังดำเนินการ</Badge>
            </div>
            {/* Massage */}
            <p className="custom-text">Lorem ipsum dolor sit amet.</p>
          </div>
        </Card.Body>
      </Card>

      <Card className="custom-card-chat">
        <Card.Body className="d-flex align-items-center gap-3">
          {/* Profile Picture */}
          <img
            src="./src/assets/Image/Customers/Harumasa.png"
            className="rounded-circle"
            style={{ width: "60px", height: "60px", objectFit: "cover" }}
          />
          {/* Texts */}
          <div className="d-flex flex-column gap-1" style={{ height: "50px" }}>
            <div className="d-flex gap-3">
              {/* Username */}
              <span style={{ fontSize: "18px" }}>Harumasa</span>
              {/* Status */}
              <Badge className="bg-warning custom-badge">กำลังดำเนินการ</Badge>
            </div>
            {/* Massage */}
            <p className="custom-text">Lorem ipsum dolor sit amet.</p>
          </div>
        </Card.Body>
      </Card>

      <Card className="custom-card-chat">
        <Card.Body className="d-flex align-items-center gap-3">
          {/* Profile Picture */}
          <img
            src="./src/assets/Image/Customers/Harumasa.png"
            className="rounded-circle"
            style={{ width: "60px", height: "60px", objectFit: "cover" }}
          />
          {/* Texts */}
          <div className="d-flex flex-column gap-1" style={{ height: "50px" }}>
            <div className="d-flex gap-3">
              {/* Username */}
              <span style={{ fontSize: "18px" }}>Harumasa</span>
              {/* Status */}
              <Badge className="bg-warning custom-badge">กำลังดำเนินการ</Badge>
            </div>
            {/* Massage */}
            <p className="custom-text">Lorem ipsum dolor sit amet.</p>
          </div>
        </Card.Body>
      </Card>

      <Card className="custom-card-chat">
        <Card.Body className="d-flex align-items-center gap-3">
          {/* Profile Picture */}
          <img
            src="./src/assets/Image/Customers/Harumasa.png"
            className="rounded-circle"
            style={{ width: "60px", height: "60px", objectFit: "cover" }}
          />
          {/* Texts */}
          <div className="d-flex flex-column gap-1" style={{ height: "50px" }}>
            <div className="d-flex gap-3">
              {/* Username */}
              <span style={{ fontSize: "18px" }}>Harumasa</span>
              {/* Status */}
              <Badge className="bg-warning custom-badge">กำลังดำเนินการ</Badge>
            </div>
            {/* Massage */}
            <p className="custom-text">Lorem ipsum dolor sit amet.</p>
          </div>
        </Card.Body>
      </Card>

      <Card className="custom-card-chat">
        <Card.Body className="d-flex align-items-center gap-3">
          {/* Profile Picture */}
          <img
            src="./src/assets/Image/Customers/Harumasa.png"
            className="rounded-circle"
            style={{ width: "60px", height: "60px", objectFit: "cover" }}
          />
          {/* Texts */}
          <div className="d-flex flex-column gap-1" style={{ height: "50px" }}>
            <div className="d-flex gap-3">
              {/* Username */}
              <span style={{ fontSize: "18px" }}>Harumasa</span>
              {/* Status */}
              <Badge className="bg-warning custom-badge">กำลังดำเนินการ</Badge>
            </div>
            {/* Massage */}
            <p className="custom-text">Lorem ipsum dolor sit amet.</p>
          </div>
        </Card.Body>
      </Card>

      <Card className="custom-card-chat">
        <Card.Body className="d-flex align-items-center gap-3">
          {/* Profile Picture */}
          <img
            src="./src/assets/Image/Customers/Harumasa.png"
            className="rounded-circle"
            style={{ width: "60px", height: "60px", objectFit: "cover" }}
          />
          {/* Texts */}
          <div className="d-flex flex-column gap-1" style={{ height: "50px" }}>
            <div className="d-flex gap-3">
              {/* Username */}
              <span style={{ fontSize: "18px" }}>Harumasa</span>
              {/* Status */}
              <Badge className="bg-warning custom-badge">กำลังดำเนินการ</Badge>
            </div>
            {/* Massage */}
            <p className="custom-text">Lorem ipsum dolor sit amet.</p>
          </div>
        </Card.Body>
      </Card>

      <Card className="custom-card-chat">
        <Card.Body className="d-flex align-items-center gap-3">
          {/* Profile Picture */}
          <img
            src="./src/assets/Image/Customers/Harumasa.png"
            className="rounded-circle"
            style={{ width: "60px", height: "60px", objectFit: "cover" }}
          />
          {/* Texts */}
          <div className="d-flex flex-column gap-1" style={{ height: "50px" }}>
            <div className="d-flex gap-3">
              {/* Username */}
              <span style={{ fontSize: "18px" }}>Harumasa</span>
              {/* Status */}
              <Badge className="bg-warning custom-badge">กำลังดำเนินการ</Badge>
            </div>
            {/* Massage */}
            <p className="custom-text">Lorem ipsum dolor sit amet.</p>
          </div>
        </Card.Body>
      </Card>

      <Card className="custom-card-chat">
        <Card.Body className="d-flex align-items-center gap-3">
          {/* Profile Picture */}
          <img
            src="./src/assets/Image/Customers/Harumasa.png"
            className="rounded-circle"
            style={{ width: "60px", height: "60px", objectFit: "cover" }}
          />
          {/* Texts */}
          <div className="d-flex flex-column gap-1" style={{ height: "50px" }}>
            <div className="d-flex gap-3">
              {/* Username */}
              <span style={{ fontSize: "18px" }}>Harumasa</span>
              {/* Status */}
              <Badge className="bg-warning custom-badge">กำลังดำเนินการ</Badge>
            </div>
            {/* Massage */}
            <p className="custom-text">Lorem ipsum dolor sit amet.</p>
          </div>
        </Card.Body>
      </Card>

      <Card className="custom-card-chat">
        <Card.Body className="d-flex align-items-center gap-3">
          {/* Profile Picture */}
          <img
            src="./src/assets/Image/Customers/Harumasa.png"
            className="rounded-circle"
            style={{ width: "60px", height: "60px", objectFit: "cover" }}
          />
          {/* Texts */}
          <div className="d-flex flex-column gap-1" style={{ height: "50px" }}>
            <div className="d-flex gap-3">
              {/* Username */}
              <span style={{ fontSize: "18px" }}>Harumasa</span>
              {/* Status */}
              <Badge className="bg-warning custom-badge">กำลังดำเนินการ</Badge>
            </div>
            {/* Massage */}
            <p className="custom-text">Lorem ipsum dolor sit amet.</p>
          </div>
        </Card.Body>
      </Card>

      <Card className="custom-card-chat">
        <Card.Body className="d-flex align-items-center gap-3">
          {/* Profile Picture */}
          <img
            src="./src/assets/Image/Customers/Harumasa.png"
            className="rounded-circle"
            style={{ width: "60px", height: "60px", objectFit: "cover" }}
          />
          {/* Texts */}
          <div className="d-flex flex-column gap-1" style={{ height: "50px" }}>
            <div className="d-flex gap-3">
              {/* Username */}
              <span style={{ fontSize: "18px" }}>Harumasa</span>
              {/* Status */}
              <Badge className="bg-warning custom-badge">กำลังดำเนินการ</Badge>
            </div>
            {/* Massage */}
            <p className="custom-text">Lorem ipsum dolor sit amet.</p>
          </div>
        </Card.Body>
      </Card>

      <Card className="custom-card-chat">
        <Card.Body className="d-flex align-items-center gap-3">
          {/* Profile Picture */}
          <img
            src="./src/assets/Image/Customers/Harumasa.png"
            className="rounded-circle"
            style={{ width: "60px", height: "60px", objectFit: "cover" }}
          />
          {/* Texts */}
          <div className="d-flex flex-column gap-1" style={{ height: "50px" }}>
            <div className="d-flex gap-3">
              {/* Username */}
              <span style={{ fontSize: "18px" }}>Harumasa</span>
              {/* Status */}
              <Badge className="bg-warning custom-badge">กำลังดำเนินการ</Badge>
            </div>
            {/* Massage */}
            <p className="custom-text">Lorem ipsum dolor sit amet.</p>
          </div>
        </Card.Body>
      </Card>
    </div>
  );
};

export default ChatList;
